#ifndef STDIO_H
#include<stdio.h>
void Vowels_count();